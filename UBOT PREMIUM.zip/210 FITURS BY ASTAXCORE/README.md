## Vii Userbot
```
apt update && apt upgrade -y
```
```
git clone https://github.com/Buyer11/ubotpremjojo
```
```
cd ubotpremjojo
```
```
apt install ffmpeg -y
```
```
bash installnode.sh
```
```
apt install python3.10-venv
```
```
python3 -m venv venv && source venv/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
screen -S ubotpremjojo
```
```
python3 -m PyroUbot
```
```
---------- Menghidupan jika ubot mati -------------
```
```
cd ubotpremjojo
```
```
python3 -m venv venv && source venv/bin/activate
```
```
screen -S ubotpremjojo
```
```
python3 -m PyroUbot
```
