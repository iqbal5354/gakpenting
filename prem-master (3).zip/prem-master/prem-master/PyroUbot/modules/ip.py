from PyroUbot import *


__MODULE__ = "ipinfo"
__HELP__ = f"""
<b>『 ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ɪᴘɪɴꜰᴏ 』</b>

  <b>• ᴘᴇʀɪɴᴛᴀʜ:</b> <code>{PREFIX[0]}ipinfo</code> [ɪᴘ ᴀᴅᴅʀᴇꜱ]
  <b>• ᴘᴇɴᴊᴇʟᴀsᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ɪɴꜰᴏʀᴍᴀꜱɪ ɪᴘ ᴀᴅᴅʀᴇꜱ 
  """


@PY.UBOT("ipinfo")
async def _(client, message):
    await hacker_lacak_target(client, message)
